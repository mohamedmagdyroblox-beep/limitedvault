import { useState, useEffect } from "react";
import { useLocation, useParams } from "wouter";
import { doc, getDoc, addDoc, collection, updateDoc } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useAuth } from "@/lib/auth-context";
import { Navbar } from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { AlertTriangle, ShoppingCart, TrendingUp, User } from "lucide-react";

interface Listing {
  id: string;
  sellerId: string;
  sellerUsername: string;
  assetId: string;
  name: string;
  imageUrl: string;
  rolimonsValue: number;
  listPrice: number;
  status: string;
  createdAt: string;
}

export default function ListingDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { user, profile } = useAuth();
  const [, setLocation] = useLocation();
  const [listing, setListing] = useState<Listing | null>(null);
  const [loading, setLoading] = useState(true);
  const [buying, setBuying] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!id) return;
    getDoc(doc(db, "listings", id)).then((snap) => {
      if (snap.exists()) setListing({ id: snap.id, ...snap.data() } as Listing);
      setLoading(false);
    });
  }, [id]);

  const handleBuy = async () => {
    if (!user || !profile || !listing) return;
    if (profile.uid === listing.sellerId) { setError("You cannot buy your own listing."); return; }
    if (profile.balance < listing.listPrice) {
      setError(`Insufficient balance. You need $${listing.listPrice.toFixed(2)} but have $${profile.balance.toFixed(2)}.`);
      return;
    }
    setBuying(true);
    setError("");
    try {
      const tradeRef = await addDoc(collection(db, "trades"), {
        listingId: listing.id,
        buyerId: user.uid,
        buyerUsername: profile.username,
        sellerId: listing.sellerId,
        sellerUsername: listing.sellerUsername,
        itemName: listing.name,
        itemImageUrl: listing.imageUrl,
        assetId: listing.assetId,
        amount: listing.listPrice,
        status: "chatting",
        buyerRobloxUsername: "",
        createdAt: new Date().toISOString(),
      });
      await updateDoc(doc(db, "listings", listing.id), { status: "sold" });
      setLocation(`/trade/${tradeRef.id}`);
    } catch (err) {
      setError("Failed to initiate trade. Please try again.");
      setBuying(false);
    }
  };

  const fallback = listing
    ? `https://www.roblox.com/asset-thumbnail/image?assetId=${listing.assetId}&width=420&height=420&format=png`
    : "";

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="max-w-4xl mx-auto px-4 pt-20 pb-12">
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Skeleton className="aspect-square rounded-2xl" />
            <div className="space-y-4">
              <Skeleton className="h-8 w-3/4" />
              <Skeleton className="h-5 w-1/2" />
              <Skeleton className="h-20 w-full" />
              <Skeleton className="h-12 w-full" />
            </div>
          </div>
        ) : !listing ? (
          <div className="text-center py-24">
            <AlertTriangle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-lg font-semibold">Listing not found</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Image */}
            <div>
              <div className="aspect-square rounded-2xl overflow-hidden bg-muted border border-border">
                <img
                  src={listing.imageUrl || fallback}
                  alt={listing.name}
                  onError={(e) => { (e.target as HTMLImageElement).src = fallback; }}
                  className="w-full h-full object-cover"
                />
              </div>
            </div>

            {/* Info */}
            <div className="flex flex-col gap-5">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Badge variant={listing.status === "active" ? "default" : "secondary"}>
                    {listing.status}
                  </Badge>
                  <span className="text-xs text-muted-foreground font-mono">#{listing.assetId}</span>
                </div>
                <h1 className="text-2xl font-bold mb-1" data-testid="text-listing-name">{listing.name}</h1>
                <div className="flex items-center gap-1.5 text-muted-foreground text-sm">
                  <User className="w-3.5 h-3.5" />
                  <span>Listed by <span className="text-foreground font-medium">{listing.sellerUsername}</span></span>
                </div>
              </div>

              {/* Price info */}
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-card border border-border rounded-xl p-4">
                  <div className="flex items-center gap-1.5 text-muted-foreground text-xs mb-1">
                    <TrendingUp className="w-3.5 h-3.5" /> Rolimons Value
                  </div>
                  <p className="text-lg font-bold font-mono">{listing.rolimonsValue.toLocaleString()}</p>
                </div>
                <div className="bg-card border border-primary/30 rounded-xl p-4">
                  <div className="flex items-center gap-1.5 text-muted-foreground text-xs mb-1">
                    <ShoppingCart className="w-3.5 h-3.5" /> Seller Price
                  </div>
                  <p className="text-2xl font-bold text-primary" data-testid="text-listing-price">${listing.listPrice.toFixed(2)}</p>
                </div>
              </div>

              {/* Buy section */}
              <div className="bg-card border border-border rounded-xl p-5">
                <h3 className="font-semibold mb-3">How it works</h3>
                <ol className="space-y-2 text-sm text-muted-foreground list-decimal list-inside">
                  <li>Click "Buy Now" — funds are held in escrow</li>
                  <li>Chat with the seller, provide your Roblox username</li>
                  <li>Complete the trade in Roblox</li>
                  <li>Click "Release Payment" to pay the seller</li>
                </ol>
              </div>

              {error && (
                <p className="text-sm text-destructive bg-destructive/10 border border-destructive/20 rounded-md px-3 py-2" data-testid="text-error">{error}</p>
              )}

              {listing.status !== "active" ? (
                <Button disabled className="w-full h-12 text-base">Item Sold</Button>
              ) : !user ? (
                <Button
                  onClick={() => setLocation("/login")}
                  className="w-full h-12 text-base gap-2 glow-primary"
                  data-testid="button-login-to-buy"
                >
                  <ShoppingCart className="w-5 h-5" /> Login to Buy
                </Button>
              ) : profile?.uid === listing.sellerId ? (
                <Button disabled className="w-full h-12 text-base">Your Listing</Button>
              ) : (
                <Button
                  onClick={handleBuy}
                  disabled={buying}
                  className="w-full h-12 text-base gap-2 glow-primary"
                  data-testid="button-buy-now"
                >
                  <ShoppingCart className="w-5 h-5" />
                  {buying ? "Processing..." : `Buy Now — $${listing.listPrice.toFixed(2)}`}
                </Button>
              )}

              {user && profile && listing.status === "active" && profile.uid !== listing.sellerId && (
                <p className="text-xs text-center text-muted-foreground">
                  Your balance: <span className="font-mono text-green-400">${profile.balance.toFixed(2)}</span>
                </p>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
