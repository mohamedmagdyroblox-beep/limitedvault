import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { collection, addDoc } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useAuth } from "@/lib/auth-context";
import { useGetRobloxInventory, getGetRobloxInventoryQueryKey, LimitedItem } from "@workspace/api-client-react";
import { Navbar } from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Package, Tag, AlertTriangle } from "lucide-react";

export default function ListItemPage() {
  const { user, profile, loading: authLoading } = useAuth();
  const [, setLocation] = useLocation();
  const [selected, setSelected] = useState<LimitedItem | null>(null);
  const [price, setPrice] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (authLoading) return;
    if (!user) { setLocation("/login"); return; }
    if (profile && !profile.verifiedRoblox) setLocation("/verify-roblox");
  }, [authLoading, user, profile, setLocation]);

  const enabled = !!profile?.robloxUserId;
  const { data: invData, isLoading, error: invError } = useGetRobloxInventory(
    profile?.robloxUserId ?? "",
    { query: { enabled, queryKey: getGetRobloxInventoryQueryKey(profile?.robloxUserId ?? "") } }
  );

  if (authLoading || !user || !profile) return null;

  const handleList = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selected) return;
    const p = parseFloat(price);
    if (isNaN(p) || p <= 0) { setError("Enter a valid price."); return; }
    setSubmitting(true);
    setError("");
    try {
      await addDoc(collection(db, "listings"), {
        sellerId: user.uid,
        sellerUsername: profile.username,
        assetId: selected.assetId,
        name: selected.name,
        imageUrl: selected.imageUrl || `https://www.roblox.com/asset-thumbnail/image?assetId=${selected.assetId}&width=150&height=150&format=png`,
        rolimonsValue: selected.value,
        listPrice: p,
        status: "active",
        createdAt: new Date().toISOString(),
      });
      setLocation("/dashboard");
    } catch (err) {
      setError("Failed to create listing. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  const items: LimitedItem[] = invData?.items ?? [];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="max-w-5xl mx-auto px-4 pt-20 pb-12">
        <div className="mb-8">
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Tag className="w-6 h-6 text-primary" /> List a Limited
          </h1>
          <p className="text-muted-foreground text-sm mt-0.5">
            Inventory for <span className="font-mono text-foreground">{profile.robloxUsername}</span>
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Inventory */}
          <div className="lg:col-span-2">
            <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">
              Your Limiteds ({items.length})
            </h2>
            {isLoading ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="rounded-xl overflow-hidden">
                    <Skeleton className="aspect-square" />
                    <div className="p-2 space-y-1.5">
                      <Skeleton className="h-3 w-3/4" />
                      <Skeleton className="h-3 w-1/2" />
                    </div>
                  </div>
                ))}
              </div>
            ) : invError ? (
              <div className="bg-card border border-border rounded-xl p-8 text-center">
                <AlertTriangle className="w-10 h-10 text-yellow-500 mx-auto mb-3" />
                <p className="font-semibold">Could not load inventory</p>
                <p className="text-muted-foreground text-sm mt-1">
                  Make sure your Rolimons profile is public and your Roblox inventory is visible.
                </p>
              </div>
            ) : items.length === 0 ? (
              <div className="bg-card border border-border rounded-xl p-8 text-center">
                <Package className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
                <p className="font-semibold">No limiteds found</p>
                <p className="text-muted-foreground text-sm mt-1">
                  Your Rolimons profile may need to be updated or your inventory may be private.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 max-h-[70vh] overflow-y-auto pr-1">
                {items.map((item) => {
                  const isSelected = selected?.assetId === item.assetId;
                  const fallback = `https://www.roblox.com/asset-thumbnail/image?assetId=${item.assetId}&width=150&height=150&format=png`;
                  return (
                    <button
                      key={item.assetId}
                      onClick={() => { setSelected(item); setPrice(String(Math.max(1, Math.round(item.value / 1000)))); }}
                      data-testid={`card-item-${item.assetId}`}
                      className={`rounded-xl border text-left overflow-hidden transition-all duration-150 ${
                        isSelected
                          ? "border-primary ring-2 ring-primary/30 bg-primary/5"
                          : "border-border bg-card hover:border-primary/40"
                      }`}
                    >
                      <img
                        src={item.imageUrl || fallback}
                        alt={item.name}
                        onError={(e) => { (e.target as HTMLImageElement).src = fallback; }}
                        className="w-full aspect-square object-cover"
                      />
                      <div className="p-2">
                        <p className="text-xs font-semibold truncate">{item.name}</p>
                        <p className="text-xs text-muted-foreground font-mono">{item.value.toLocaleString()} RAP</p>
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* List form */}
          <div>
            <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">Listing Details</h2>
            {selected ? (
              <div className="bg-card border border-border rounded-xl p-5 sticky top-20">
                <img
                  src={selected.imageUrl || `https://www.roblox.com/asset-thumbnail/image?assetId=${selected.assetId}&width=150&height=150&format=png`}
                  alt={selected.name}
                  className="w-24 h-24 rounded-lg object-cover mx-auto mb-4"
                />
                <p className="font-semibold text-center mb-1">{selected.name}</p>
                <p className="text-xs text-center text-muted-foreground font-mono mb-4">
                  Rolimons value: {selected.value.toLocaleString()}
                </p>
                <form onSubmit={handleList} className="space-y-4">
                  <div className="space-y-1.5">
                    <Label htmlFor="price">Your Price (USD)</Label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">$</span>
                      <Input
                        id="price"
                        data-testid="input-price"
                        type="number"
                        min="0.01"
                        step="0.01"
                        placeholder="0.00"
                        value={price}
                        onChange={(e) => setPrice(e.target.value)}
                        className="pl-7"
                        required
                      />
                    </div>
                  </div>
                  {error && (
                    <p className="text-sm text-destructive bg-destructive/10 border border-destructive/20 rounded-md px-3 py-2">{error}</p>
                  )}
                  <Button
                    type="submit"
                    className="w-full glow-primary"
                    disabled={submitting}
                    data-testid="button-list-submit"
                  >
                    {submitting ? "Listing..." : "List for Sale"}
                  </Button>
                </form>
              </div>
            ) : (
              <div className="bg-card border border-dashed border-border rounded-xl p-8 text-center text-muted-foreground">
                <Tag className="w-8 h-8 mx-auto mb-2 opacity-40" />
                <p className="text-sm">Select an item from your inventory</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
