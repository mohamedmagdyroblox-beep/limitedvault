import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { collection, query, where, onSnapshot, doc, updateDoc } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useAuth } from "@/lib/auth-context";
import { Navbar } from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { CheckCircle, XCircle, Plus, ShieldCheck, Wallet, Tag, Trash2 } from "lucide-react";

interface Listing {
  id: string;
  name: string;
  imageUrl: string;
  rolimonsValue: number;
  listPrice: number;
  status: string;
  assetId: string;
  createdAt: string;
}

export default function DashboardPage() {
  const { user, profile, loading: authLoading } = useAuth();
  const [, setLocation] = useLocation();
  const [listings, setListings] = useState<Listing[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!authLoading && !user) setLocation("/login");
  }, [authLoading, user, setLocation]);

  useEffect(() => {
    if (!user) return;
    const q = query(
      collection(db, "listings"),
      where("sellerId", "==", user.uid)
    );
    const unsub = onSnapshot(q, (snap) => {
      const items = snap.docs.map((d) => ({ id: d.id, ...d.data() } as Listing));
      items.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
      setListings(items);
      setLoading(false);
    });
    return () => unsub();
  }, [user]);

  if (authLoading || !user || !profile) return null;

  const cancelListing = async (id: string) => {
    await updateDoc(doc(db, "listings", id), { status: "cancelled" });
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="max-w-5xl mx-auto px-4 pt-20 pb-12">
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Dashboard</h1>
            <p className="text-muted-foreground text-sm mt-0.5">Welcome back, {profile.username}</p>
          </div>
          {profile.verifiedRoblox && (
            <Link href="/list-item">
              <Button className="gap-2 glow-primary" data-testid="button-list-item">
                <Plus className="w-4 h-4" /> List Item
              </Button>
            </Link>
          )}
        </div>

        {/* Account cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
          <div className="bg-card border border-border rounded-xl p-4">
            <p className="text-xs text-muted-foreground mb-1">Balance</p>
            <p className="text-2xl font-bold text-green-400 font-mono" data-testid="text-balance">${profile.balance.toFixed(2)}</p>
            <Link href="/balance">
              <Button variant="outline" size="sm" className="mt-3 gap-1.5 w-full">
                <Wallet className="w-3.5 h-3.5" /> Deposit
              </Button>
            </Link>
          </div>
          <div className="bg-card border border-border rounded-xl p-4">
            <p className="text-xs text-muted-foreground mb-1">Roblox Account</p>
            {profile.verifiedRoblox ? (
              <div>
                <div className="flex items-center gap-1.5 text-green-400">
                  <CheckCircle className="w-4 h-4" />
                  <span className="font-semibold text-sm">Verified</span>
                </div>
                <p className="text-sm mt-1 text-foreground font-mono">{profile.robloxUsername}</p>
              </div>
            ) : (
              <div>
                <div className="flex items-center gap-1.5 text-yellow-500">
                  <XCircle className="w-4 h-4" />
                  <span className="font-semibold text-sm">Not verified</span>
                </div>
                <Link href="/verify-roblox">
                  <Button size="sm" className="mt-3 gap-1.5 w-full">
                    <ShieldCheck className="w-3.5 h-3.5" /> Verify Now
                  </Button>
                </Link>
              </div>
            )}
          </div>
          <div className="bg-card border border-border rounded-xl p-4">
            <p className="text-xs text-muted-foreground mb-1">Active Listings</p>
            <p className="text-2xl font-bold">{listings.filter((l) => l.status === "active").length}</p>
            <p className="text-xs text-muted-foreground mt-1">
              {listings.filter((l) => l.status === "sold").length} sold
            </p>
          </div>
        </div>

        {/* Listings */}
        <div>
          <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <Tag className="w-4 h-4 text-primary" /> My Listings
          </h2>
          {loading ? (
            <div className="space-y-3">
              {[1, 2, 3].map((i) => <Skeleton key={i} className="h-20 w-full rounded-xl" />)}
            </div>
          ) : listings.length === 0 ? (
            <div className="text-center py-12 bg-card border border-border rounded-xl">
              <Tag className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
              <p className="font-semibold mb-1">No listings yet</p>
              <p className="text-muted-foreground text-sm mb-4">
                {profile.verifiedRoblox ? "List your first limited to start selling." : "Verify your Roblox account first."}
              </p>
              {profile.verifiedRoblox ? (
                <Link href="/list-item"><Button className="gap-2"><Plus className="w-4 h-4" /> List Item</Button></Link>
              ) : (
                <Link href="/verify-roblox"><Button variant="outline" className="gap-2"><ShieldCheck className="w-4 h-4" /> Verify Roblox</Button></Link>
              )}
            </div>
          ) : (
            <div className="space-y-3">
              {listings.map((l) => (
                <div key={l.id} data-testid={`card-listing-${l.id}`} className="bg-card border border-border rounded-xl p-4 flex items-center gap-4">
                  <img
                    src={l.imageUrl || `https://www.roblox.com/asset-thumbnail/image?assetId=${l.assetId}&width=60&height=60&format=png`}
                    alt={l.name}
                    className="w-14 h-14 rounded-lg object-cover bg-muted shrink-0"
                    onError={(e) => { (e.target as HTMLImageElement).src = `https://www.roblox.com/asset-thumbnail/image?assetId=${l.assetId}&width=60&height=60&format=png`; }}
                  />
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold truncate">{l.name}</p>
                    <p className="text-xs text-muted-foreground">RAP: {l.rolimonsValue.toLocaleString()}</p>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="font-bold text-primary">${l.listPrice.toFixed(2)}</p>
                    <Badge
                      variant={l.status === "active" ? "default" : l.status === "sold" ? "secondary" : "destructive"}
                      className="text-xs mt-1"
                    >
                      {l.status}
                    </Badge>
                  </div>
                  {l.status === "active" && (
                    <button
                      onClick={() => cancelListing(l.id)}
                      data-testid={`button-cancel-${l.id}`}
                      className="p-2 rounded-lg hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
