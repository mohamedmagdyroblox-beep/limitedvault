import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { doc, updateDoc } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useAuth } from "@/lib/auth-context";
import { useGetRobloxVerifyPhrase, useConfirmRobloxVerification } from "@workspace/api-client-react";
import { Navbar } from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Copy, ShieldCheck, ArrowRight } from "lucide-react";

export default function VerifyRobloxPage() {
  const { user, profile, loading: authLoading, refreshProfile } = useAuth();
  const [, setLocation] = useLocation();
  const [step, setStep] = useState<1 | 2>(1);
  const [robloxUsername, setRobloxUsername] = useState("");
  const [phrase, setPhrase] = useState("");
  const [robloxUserId, setRobloxUserId] = useState("");
  const [confirmedUsername, setConfirmedUsername] = useState("");
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);

  const getPhrase = useGetRobloxVerifyPhrase();
  const confirmVerify = useConfirmRobloxVerification();

  useEffect(() => {
    if (authLoading) return;
    if (!user) { setLocation("/login"); return; }
    if (profile?.verifiedRoblox) setLocation("/dashboard");
  }, [authLoading, user, profile, setLocation]);

  if (authLoading || !user || !profile) return null;
  if (profile.verifiedRoblox) return null;

  const handleGetPhrase = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    getPhrase.mutate(
      { data: { robloxUsername, userId: user.uid } },
      {
        onSuccess: (data) => {
          setPhrase(data.phrase);
          setRobloxUserId(data.robloxUserId);
          setConfirmedUsername(data.robloxUsername);
          setStep(2);
        },
        onError: (err: unknown) => {
          const msg = err instanceof Error ? err.message : "Failed to find Roblox user";
          setError(msg.includes("404") ? "Roblox user not found. Check the username." : msg);
        },
      }
    );
  };

  const handleConfirm = async () => {
    setError("");
    confirmVerify.mutate(
      { data: { robloxUserId, phrase } },
      {
        onSuccess: async () => {
          await updateDoc(doc(db, "users", user.uid), {
            verifiedRoblox: true,
            robloxUsername: confirmedUsername,
            robloxUserId,
          });
          await refreshProfile();
          setSuccess(true);
          setTimeout(() => setLocation("/dashboard"), 2000);
        },
        onError: () => {
          setError("Phrase not found in your bio. Make sure you saved your Roblox profile after updating.");
        },
      }
    );
  };

  const copyPhrase = () => {
    navigator.clipboard.writeText(phrase);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="max-w-lg mx-auto px-4 pt-20 pb-12">
        <div className="mb-8">
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <ShieldCheck className="w-6 h-6 text-primary" /> Verify Roblox Account
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            Link your Roblox account to list your limiteds.
          </p>
        </div>

        {/* Steps */}
        <div className="flex items-center gap-2 mb-8">
          <div className={`flex items-center gap-2 text-sm font-medium ${step >= 1 ? "text-primary" : "text-muted-foreground"}`}>
            <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs ${step >= 1 ? "bg-primary text-white" : "bg-muted text-muted-foreground"}`}>1</div>
            Enter username
          </div>
          <div className="flex-1 h-px bg-border" />
          <div className={`flex items-center gap-2 text-sm font-medium ${step >= 2 ? "text-primary" : "text-muted-foreground"}`}>
            <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs ${step >= 2 ? "bg-primary text-white" : "bg-muted text-muted-foreground"}`}>2</div>
            Confirm bio
          </div>
        </div>

        {success ? (
          <div className="bg-card border border-green-500/30 rounded-xl p-8 text-center">
            <CheckCircle className="w-12 h-12 text-green-400 mx-auto mb-3" />
            <p className="text-lg font-bold text-green-400">Verified!</p>
            <p className="text-muted-foreground text-sm mt-1">Redirecting to dashboard...</p>
          </div>
        ) : step === 1 ? (
          <div className="bg-card border border-border rounded-xl p-6">
            <form onSubmit={handleGetPhrase} className="space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="roblox-username">Roblox Username</Label>
                <Input
                  id="roblox-username"
                  data-testid="input-roblox-username"
                  placeholder="YourRobloxUsername"
                  value={robloxUsername}
                  onChange={(e) => setRobloxUsername(e.target.value)}
                  required
                  autoFocus
                />
              </div>
              {error && (
                <p className="text-sm text-destructive bg-destructive/10 border border-destructive/20 rounded-md px-3 py-2">{error}</p>
              )}
              <Button
                type="submit"
                className="w-full gap-2 glow-primary"
                disabled={getPhrase.isPending}
                data-testid="button-get-phrase"
              >
                {getPhrase.isPending ? "Looking up..." : "Get Verification Phrase"}
                <ArrowRight className="w-4 h-4" />
              </Button>
            </form>
          </div>
        ) : (
          <div className="bg-card border border-border rounded-xl p-6 space-y-5">
            <div>
              <p className="text-sm font-medium mb-1 text-muted-foreground">Roblox account found</p>
              <Badge variant="secondary" className="font-mono">{confirmedUsername}</Badge>
            </div>

            <div>
              <p className="text-sm font-semibold mb-2">Step 1 — Copy this phrase</p>
              <div className="bg-muted rounded-lg p-4 flex items-center justify-between gap-3 border border-border">
                <code className="text-sm font-mono text-primary break-all" data-testid="text-phrase">{phrase}</code>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={copyPhrase}
                  className="shrink-0 gap-1.5"
                  data-testid="button-copy-phrase"
                >
                  <Copy className="w-3.5 h-3.5" />
                  {copied ? "Copied!" : "Copy"}
                </Button>
              </div>
            </div>

            <div className="bg-muted/50 rounded-lg p-4 text-sm text-muted-foreground space-y-1.5 border border-border/50">
              <p className="font-medium text-foreground">Step 2 — Update your Roblox bio</p>
              <p>1. Go to <span className="text-primary font-mono">roblox.com/users/profile</span></p>
              <p>2. Click <strong className="text-foreground">Edit Profile</strong></p>
              <p>3. Paste the phrase anywhere in your bio</p>
              <p>4. Click <strong className="text-foreground">Save</strong></p>
              <p>5. Come back and click the button below</p>
            </div>

            {error && (
              <p className="text-sm text-destructive bg-destructive/10 border border-destructive/20 rounded-md px-3 py-2">{error}</p>
            )}

            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => { setStep(1); setError(""); }}
                className="flex-1"
              >
                Back
              </Button>
              <Button
                onClick={handleConfirm}
                className="flex-1 gap-2 glow-primary"
                disabled={confirmVerify.isPending}
                data-testid="button-confirm-verify"
              >
                {confirmVerify.isPending ? "Checking..." : "I've updated my bio"}
                <CheckCircle className="w-4 h-4" />
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
