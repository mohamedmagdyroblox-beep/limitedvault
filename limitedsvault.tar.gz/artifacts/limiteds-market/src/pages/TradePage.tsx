import { useState, useEffect, useRef } from "react";
import { useParams, useLocation } from "wouter";
import {
  doc, getDoc, onSnapshot, collection, addDoc, updateDoc,
  query, orderBy, runTransaction
} from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useAuth } from "@/lib/auth-context";
import { Navbar } from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Send, CheckCircle, AlertTriangle, Clock } from "lucide-react";

interface Trade {
  id: string;
  listingId: string;
  buyerId: string;
  buyerUsername: string;
  sellerId: string;
  sellerUsername: string;
  itemName: string;
  itemImageUrl: string;
  assetId: string;
  amount: number;
  status: string;
  buyerRobloxUsername: string;
  createdAt: string;
}

interface Message {
  id: string;
  senderId: string;
  senderUsername: string;
  text: string;
  createdAt: string;
}

export default function TradePage() {
  const { id } = useParams<{ id: string }>();
  const { user, profile, loading: authLoading, refreshProfile } = useAuth();
  const [, setLocation] = useLocation();
  const [trade, setTrade] = useState<Trade | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(true);
  const [releasing, setReleasing] = useState(false);
  const [error, setError] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!id) return;
    const unsub = onSnapshot(doc(db, "trades", id), (snap) => {
      if (snap.exists()) setTrade({ id: snap.id, ...snap.data() } as Trade);
      setLoading(false);
    });
    return () => unsub();
  }, [id]);

  useEffect(() => {
    if (!id) return;
    const q = query(collection(db, "chats", id, "messages"), orderBy("createdAt", "asc"));
    const unsub = onSnapshot(q, (snap) => {
      setMessages(snap.docs.map((d) => ({ id: d.id, ...d.data() } as Message)));
    });
    return () => unsub();
  }, [id]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  useEffect(() => {
    if (!authLoading && !user) setLocation("/login");
  }, [authLoading, user, setLocation]);

  if (authLoading || !user || !profile) return null;

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim() || !id) return;
    const msg = text.trim();
    setText("");
    await addDoc(collection(db, "chats", id, "messages"), {
      senderId: user.uid,
      senderUsername: profile.username,
      text: msg,
      createdAt: new Date().toISOString(),
    });
  };

  const handleRelease = async () => {
    if (!trade || !user || !profile) return;
    if (profile.balance < trade.amount) {
      setError("Insufficient balance to release payment.");
      return;
    }
    setReleasing(true);
    setError("");
    try {
      await runTransaction(db, async (tx) => {
        const buyerRef = doc(db, "users", trade.buyerId);
        const sellerRef = doc(db, "users", trade.sellerId);
        const tradeRef = doc(db, "trades", trade.id);

        const buyerSnap = await tx.get(buyerRef);
        const sellerSnap = await tx.get(sellerRef);

        if (!buyerSnap.exists() || !sellerSnap.exists()) throw new Error("User not found");

        const buyerBalance = buyerSnap.data().balance as number;
        const sellerBalance = sellerSnap.data().balance as number;

        if (buyerBalance < trade.amount) throw new Error("Insufficient balance");

        tx.update(buyerRef, { balance: buyerBalance - trade.amount });
        tx.update(sellerRef, { balance: sellerBalance + trade.amount });
        tx.update(tradeRef, { status: "completed" });
      });
      await refreshProfile();
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Transaction failed";
      setError(msg);
      setReleasing(false);
    }
  };

  const isBuyer = trade?.buyerId === user.uid;
  const isSeller = trade?.sellerId === user.uid;

  const statusColor: Record<string, string> = {
    chatting: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20",
    completed: "bg-green-500/10 text-green-400 border-green-500/20",
    cancelled: "bg-red-500/10 text-red-400 border-red-500/20",
    pending: "bg-blue-500/10 text-blue-400 border-blue-500/20",
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />
      <div className="max-w-4xl mx-auto w-full px-4 pt-20 pb-4 flex flex-col flex-1">
        {loading ? (
          <div className="space-y-4 mt-4">
            <Skeleton className="h-24 w-full rounded-xl" />
            <Skeleton className="h-96 w-full rounded-xl" />
          </div>
        ) : !trade ? (
          <div className="text-center py-24">
            <AlertTriangle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-lg font-semibold">Trade not found</p>
          </div>
        ) : !isBuyer && !isSeller ? (
          <div className="text-center py-24">
            <AlertTriangle className="w-12 h-12 text-destructive mx-auto mb-4" />
            <p className="text-lg font-semibold">Access denied</p>
          </div>
        ) : (
          <div className="flex flex-col gap-4 flex-1">
            {/* Trade header */}
            <div className="bg-card border border-border rounded-xl p-4 flex items-center gap-4">
              <img
                src={trade.itemImageUrl || `https://www.roblox.com/asset-thumbnail/image?assetId=${trade.assetId}&width=80&height=80&format=png`}
                alt={trade.itemName}
                className="w-16 h-16 rounded-lg object-cover bg-muted shrink-0"
                onError={(e) => { (e.target as HTMLImageElement).src = `https://www.roblox.com/asset-thumbnail/image?assetId=${trade.assetId}&width=80&height=80&format=png`; }}
              />
              <div className="flex-1 min-w-0">
                <p className="font-bold truncate">{trade.itemName}</p>
                <p className="text-sm text-muted-foreground">
                  <span className="text-foreground font-medium">{trade.buyerUsername}</span> buying from{" "}
                  <span className="text-foreground font-medium">{trade.sellerUsername}</span>
                </p>
                <p className="text-xs text-muted-foreground mt-0.5">Trade ID: <span className="font-mono">{trade.id}</span></p>
              </div>
              <div className="text-right shrink-0">
                <p className="text-xl font-bold text-primary">${(trade.amount ?? 0).toFixed(2)}</p>
                <span className={`text-xs px-2 py-0.5 rounded-full border font-medium ${statusColor[trade.status] ?? ""}`}>
                  {trade.status}
                </span>
              </div>
            </div>

            {/* Status instructions */}
            {trade.status === "chatting" && (
              <div className={`rounded-lg border px-4 py-3 text-sm flex items-start gap-2 ${isBuyer ? "bg-blue-500/5 border-blue-500/20 text-blue-300" : "bg-yellow-500/5 border-yellow-500/20 text-yellow-300"}`}>
                <Clock className="w-4 h-4 mt-0.5 shrink-0" />
                {isBuyer
                  ? "Tell the seller your Roblox username below. Once the trade is complete in Roblox, click Release Payment."
                  : "Wait for the buyer to message you with their Roblox username, then complete the trade in Roblox."}
              </div>
            )}
            {trade.status === "completed" && (
              <div className="rounded-lg border bg-green-500/5 border-green-500/20 px-4 py-3 text-sm text-green-300 flex items-center gap-2">
                <CheckCircle className="w-4 h-4" />
                Trade completed. Payment has been released.
              </div>
            )}

            {/* Chat */}
            <div className="flex-1 bg-card border border-border rounded-xl flex flex-col min-h-0" style={{ minHeight: 320 }}>
              <div className="px-4 py-3 border-b border-border flex items-center gap-2">
                <Send className="w-4 h-4 text-primary" />
                <span className="font-semibold text-sm">Live Chat</span>
              </div>
              <div className="flex-1 overflow-y-auto p-4 space-y-3" style={{ maxHeight: 400 }}>
                {messages.length === 0 && (
                  <p className="text-center text-muted-foreground text-sm py-8">
                    No messages yet. Start the conversation.
                  </p>
                )}
                {messages.map((msg) => {
                  const isMe = msg.senderId === user.uid;
                  return (
                    <div key={msg.id} className={`flex ${isMe ? "justify-end" : "justify-start"}`}>
                      <div className={`max-w-[75%] rounded-2xl px-3.5 py-2.5 ${
                        isMe
                          ? "bg-primary text-primary-foreground rounded-br-sm"
                          : "bg-muted text-foreground rounded-bl-sm"
                      }`}>
                        {!isMe && (
                          <p className="text-xs font-semibold mb-0.5 opacity-70">{msg.senderUsername}</p>
                        )}
                        <p className="text-sm break-words">{msg.text}</p>
                        <p className="text-xs mt-1 opacity-50 text-right">
                          {new Date(msg.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                        </p>
                      </div>
                    </div>
                  );
                })}
                <div ref={bottomRef} />
              </div>
              {trade.status === "chatting" && (
                <form onSubmit={sendMessage} className="p-3 border-t border-border flex gap-2">
                  <Input
                    data-testid="input-message"
                    value={text}
                    onChange={(e) => setText(e.target.value)}
                    placeholder="Type a message..."
                    className="flex-1"
                    autoComplete="off"
                  />
                  <Button type="submit" size="icon" disabled={!text.trim()} data-testid="button-send">
                    <Send className="w-4 h-4" />
                  </Button>
                </form>
              )}
            </div>

            {/* Release payment */}
            {error && (
              <p className="text-sm text-destructive bg-destructive/10 border border-destructive/20 rounded-md px-3 py-2" data-testid="text-error">{error}</p>
            )}
            {isBuyer && trade.status === "chatting" && (
              <Button
                onClick={handleRelease}
                disabled={releasing}
                className="w-full h-12 text-base gap-2 bg-green-600 hover:bg-green-500 text-white"
                data-testid="button-release-payment"
              >
                <CheckCircle className="w-5 h-5" />
                {releasing ? "Processing..." : `Release Payment — $${(trade.amount ?? 0).toFixed(2)}`}
              </Button>
            )}
            {isSeller && trade.status === "chatting" && (
              <div className="bg-card border border-border rounded-xl p-4 text-center text-sm text-muted-foreground">
                <Clock className="w-5 h-5 mx-auto mb-2 text-yellow-500" />
                Waiting for buyer to release payment after the Roblox trade is complete.
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
