import { useState, useEffect } from "react";
import { collection, query, orderBy, onSnapshot, doc, updateDoc, getDoc } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Shield, Users, ShoppingCart, MessageSquare, Wallet, LogOut, Send } from "lucide-react";
import { collection as firestoreCollection, getDocs } from "firebase/firestore";

const ADMIN_PASSWORD = "egypt123";

type Tab = "users" | "listings" | "trades" | "chats" | "deposits";

interface UserRow { uid: string; username: string; email: string; balance: number; verifiedRoblox: boolean; createdAt: string; }
interface ListingRow { id: string; name: string; sellerUsername: string; listPrice: number; status: string; createdAt: string; }
interface TradeRow { id: string; itemName: string; buyerUsername: string; sellerUsername: string; amount: number; status: string; createdAt: string; }
interface ChatMessage { id: string; senderUsername: string; text: string; createdAt: string; }
interface DepositRow { id: string; username: string; method: string; amount: number; status: string; createdAt: string; }

export default function AdminPage() {
  const [authed, setAuthed] = useState(false);
  const [pw, setPw] = useState("");
  const [pwError, setPwError] = useState(false);
  const [tab, setTab] = useState<Tab>("trades");

  const [users, setUsers] = useState<UserRow[]>([]);
  const [listings, setListings] = useState<ListingRow[]>([]);
  const [trades, setTrades] = useState<TradeRow[]>([]);
  const [deposits, setDeposits] = useState<DepositRow[]>([]);
  const [loading, setLoading] = useState(true);

  const [selectedTrade, setSelectedTrade] = useState<string>("");
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [chatLoading, setChatLoading] = useState(false);

  useEffect(() => {
    if (!authed) return;
    setLoading(true);

    const unsubTrades = onSnapshot(query(collection(db, "trades"), orderBy("createdAt", "desc")), (snap) => {
      setTrades(snap.docs.map((d) => ({ id: d.id, ...d.data() } as TradeRow)));
      setLoading(false);
    });
    const unsubListings = onSnapshot(query(collection(db, "listings"), orderBy("createdAt", "desc")), (snap) => {
      setListings(snap.docs.map((d) => ({ id: d.id, ...d.data() } as ListingRow)));
    });
    const unsubUsers = onSnapshot(query(collection(db, "users"), orderBy("createdAt", "desc")), (snap) => {
      setUsers(snap.docs.map((d) => ({ uid: d.id, ...d.data() } as UserRow)));
    });
    const unsubDeposits = onSnapshot(query(collection(db, "balanceRequests"), orderBy("createdAt", "desc")), (snap) => {
      setDeposits(snap.docs.map((d) => ({ id: d.id, ...d.data() } as DepositRow)));
    });

    return () => { unsubTrades(); unsubListings(); unsubUsers(); unsubDeposits(); };
  }, [authed]);

  useEffect(() => {
    if (!selectedTrade) return;
    setChatLoading(true);
    const q = query(firestoreCollection(db, "chats", selectedTrade, "messages"), orderBy("createdAt", "asc"));
    const unsub = onSnapshot(q, (snap) => {
      setChatMessages(snap.docs.map((d) => ({ id: d.id, ...d.data() } as ChatMessage)));
      setChatLoading(false);
    });
    return () => unsub();
  }, [selectedTrade]);

  if (!authed) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center px-4">
        <div className="w-full max-w-sm">
          <div className="text-center mb-8">
            <div className="w-12 h-12 rounded-xl bg-primary mx-auto flex items-center justify-center mb-4">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-2xl font-bold">Admin Panel</h1>
            <p className="text-muted-foreground text-sm mt-1">Enter the admin password</p>
          </div>
          <div className="bg-card border border-border rounded-xl p-6">
            <form onSubmit={(e) => { e.preventDefault(); if (pw === ADMIN_PASSWORD) { setAuthed(true); setPwError(false); } else { setPwError(true); } }} className="space-y-4">
              <Input
                data-testid="input-admin-password"
                type="password"
                placeholder="••••••••"
                value={pw}
                onChange={(e) => setPw(e.target.value)}
                autoFocus
              />
              {pwError && <p className="text-sm text-destructive">Incorrect password.</p>}
              <Button type="submit" className="w-full glow-primary" data-testid="button-admin-login">Access Panel</Button>
            </form>
          </div>
        </div>
      </div>
    );
  }

  const TABS: { id: Tab; label: string; icon: React.ElementType; count?: number }[] = [
    { id: "trades", label: "Trades", icon: ShoppingCart, count: trades.length },
    { id: "users", label: "Users", icon: Users, count: users.length },
    { id: "listings", label: "Listings", icon: ShoppingCart, count: listings.length },
    { id: "chats", label: "Chats", icon: MessageSquare },
    { id: "deposits", label: "Deposits", icon: Wallet, count: deposits.filter((d) => d.status === "pending").length },
  ];

  const statusColor: Record<string, string> = {
    chatting: "bg-yellow-500/10 text-yellow-400",
    completed: "bg-green-500/10 text-green-400",
    cancelled: "bg-red-500/10 text-red-400",
    active: "bg-blue-500/10 text-blue-400",
    sold: "bg-purple-500/10 text-purple-400",
    pending: "bg-yellow-500/10 text-yellow-400",
    approved: "bg-green-500/10 text-green-400",
    rejected: "bg-red-500/10 text-red-400",
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-6xl mx-auto px-4 py-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-primary flex items-center justify-center">
              <Shield className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="font-bold text-lg">LimitedsVault Admin</h1>
              <p className="text-xs text-muted-foreground">Moderation Panel</p>
            </div>
          </div>
          <Button variant="outline" size="sm" onClick={() => setAuthed(false)} className="gap-1.5">
            <LogOut className="w-3.5 h-3.5" /> Lock
          </Button>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 mb-6 bg-muted p-1 rounded-lg overflow-x-auto">
          {TABS.map((t) => {
            const Icon = t.icon;
            return (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                data-testid={`tab-admin-${t.id}`}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-sm font-medium transition-all whitespace-nowrap ${
                  tab === t.id ? "bg-card text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                {t.label}
                {t.count !== undefined && t.count > 0 && (
                  <span className="bg-primary text-primary-foreground text-xs rounded-full px-1.5 py-0.5 leading-none">{t.count}</span>
                )}
              </button>
            );
          })}
        </div>

        {/* Content */}
        {loading ? (
          <div className="space-y-3">{[1, 2, 3, 4, 5].map((i) => <Skeleton key={i} className="h-14 rounded-xl" />)}</div>
        ) : (
          <>
            {tab === "trades" && (
              <div className="space-y-2">
                {trades.map((t) => (
                  <div key={t.id} data-testid={`row-admin-trade-${t.id}`} className="bg-card border border-border rounded-xl px-4 py-3 flex items-center gap-4">
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm truncate">{t.itemName}</p>
                      <p className="text-xs text-muted-foreground">{t.buyerUsername} → {t.sellerUsername}</p>
                      <p className="text-xs font-mono text-muted-foreground">{t.id.slice(0, 16)}...</p>
                    </div>
                    <p className="font-bold font-mono">${t.amount.toFixed(2)}</p>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${statusColor[t.status] ?? ""}`}>{t.status}</span>
                    <p className="text-xs text-muted-foreground shrink-0">{new Date(t.createdAt).toLocaleDateString()}</p>
                  </div>
                ))}
              </div>
            )}

            {tab === "users" && (
              <div className="space-y-2">
                {users.map((u) => (
                  <div key={u.uid} data-testid={`row-admin-user-${u.uid}`} className="bg-card border border-border rounded-xl px-4 py-3 flex items-center gap-4">
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm">{u.username}</p>
                      <p className="text-xs text-muted-foreground">{u.email}</p>
                    </div>
                    <p className="font-mono text-sm text-green-400">${u.balance?.toFixed(2) ?? "0.00"}</p>
                    {u.verifiedRoblox && <Badge variant="secondary" className="text-xs">Roblox OK</Badge>}
                    <p className="text-xs text-muted-foreground">{new Date(u.createdAt).toLocaleDateString()}</p>
                  </div>
                ))}
              </div>
            )}

            {tab === "listings" && (
              <div className="space-y-2">
                {listings.map((l) => (
                  <div key={l.id} data-testid={`row-admin-listing-${l.id}`} className="bg-card border border-border rounded-xl px-4 py-3 flex items-center gap-4">
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm truncate">{l.name}</p>
                      <p className="text-xs text-muted-foreground">by {l.sellerUsername}</p>
                    </div>
                    <p className="font-bold font-mono">${l.listPrice.toFixed(2)}</p>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${statusColor[l.status] ?? ""}`}>{l.status}</span>
                    <p className="text-xs text-muted-foreground">{new Date(l.createdAt).toLocaleDateString()}</p>
                  </div>
                ))}
              </div>
            )}

            {tab === "chats" && (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <p className="text-xs font-semibold text-muted-foreground uppercase mb-2">Select Trade</p>
                  {trades.map((t) => (
                    <button
                      key={t.id}
                      onClick={() => setSelectedTrade(t.id)}
                      data-testid={`button-trade-chat-${t.id}`}
                      className={`w-full text-left rounded-lg border px-3 py-2 text-sm transition-all ${
                        selectedTrade === t.id ? "border-primary bg-primary/10" : "border-border bg-card hover:border-primary/40"
                      }`}
                    >
                      <p className="font-medium truncate">{t.itemName}</p>
                      <p className="text-xs text-muted-foreground">{t.buyerUsername} / {t.sellerUsername}</p>
                    </button>
                  ))}
                </div>
                <div className="md:col-span-2 bg-card border border-border rounded-xl flex flex-col" style={{ minHeight: 400 }}>
                  <div className="px-4 py-3 border-b border-border">
                    <p className="font-semibold text-sm">{selectedTrade ? `Chat: ${selectedTrade.slice(0, 16)}...` : "Select a trade"}</p>
                  </div>
                  <div className="flex-1 overflow-y-auto p-4 space-y-3" style={{ maxHeight: 500 }}>
                    {chatLoading ? (
                      <Skeleton className="h-full" />
                    ) : chatMessages.length === 0 ? (
                      <p className="text-center text-muted-foreground text-sm py-8">No messages in this chat.</p>
                    ) : (
                      chatMessages.map((msg) => (
                        <div key={msg.id} className="bg-muted rounded-lg px-3 py-2">
                          <p className="text-xs font-semibold text-primary mb-0.5">{msg.senderUsername}</p>
                          <p className="text-sm">{msg.text}</p>
                          <p className="text-xs text-muted-foreground mt-0.5">
                            {new Date(msg.createdAt).toLocaleString()}
                          </p>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>
            )}

            {tab === "deposits" && (
              <div className="space-y-2">
                {deposits.map((d) => (
                  <div key={d.id} data-testid={`row-admin-deposit-${d.id}`} className="bg-card border border-border rounded-xl px-4 py-3 flex items-center gap-4">
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm">{d.username}</p>
                      <p className="text-xs text-muted-foreground capitalize">{d.method}</p>
                    </div>
                    <p className="font-bold font-mono">${d.amount.toFixed(2)}</p>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${statusColor[d.status] ?? ""}`}>{d.status}</span>
                    {d.status === "pending" && (
                      <div className="flex gap-1">
                        <Button
                          size="sm"
                          variant="outline"
                          className="text-green-400 border-green-500/30 hover:bg-green-500/10 text-xs h-7"
                          onClick={() => updateDoc(doc(db, "balanceRequests", d.id), { status: "approved" })}
                          data-testid={`button-approve-${d.id}`}
                        >
                          Approve
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="text-destructive border-destructive/30 hover:bg-destructive/10 text-xs h-7"
                          onClick={() => updateDoc(doc(db, "balanceRequests", d.id), { status: "rejected" })}
                          data-testid={`button-reject-${d.id}`}
                        >
                          Reject
                        </Button>
                      </div>
                    )}
                    <p className="text-xs text-muted-foreground shrink-0">{new Date(d.createdAt).toLocaleDateString()}</p>
                  </div>
                ))}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
