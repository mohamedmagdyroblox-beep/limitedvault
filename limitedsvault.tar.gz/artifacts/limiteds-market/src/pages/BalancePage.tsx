import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { collection, query, where, onSnapshot, addDoc } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useAuth } from "@/lib/auth-context";
import { Navbar } from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Wallet, Bitcoin, CreditCard, DollarSign, Clock } from "lucide-react";

type Method = "crypto" | "paypal" | "cashapp";

interface BalanceRequest {
  id: string;
  method: Method;
  amount: number;
  status: string;
  createdAt: string;
}

const METHODS = [
  {
    id: "crypto" as Method,
    label: "Cryptocurrency",
    icon: Bitcoin,
    description: "Bitcoin, Ethereum, USDT, and more",
    instructions: "Contact support via Discord or email to get our crypto wallet address. Send the exact amount and share your transaction ID.",
  },
  {
    id: "paypal" as Method,
    label: "PayPal",
    icon: CreditCard,
    description: "Fast and secure",
    instructions: "Contact support to get our PayPal address. Send as Friends & Family. Include your LimitedsVault username in the note.",
  },
  {
    id: "cashapp" as Method,
    label: "Cash App",
    icon: DollarSign,
    description: "Instant transfer",
    instructions: "Contact support for our $Cashtag. Send the payment and include your username in the note.",
  },
];

export default function BalancePage() {
  const { user, profile, loading: authLoading } = useAuth();
  const [, setLocation] = useLocation();
  const [selectedMethod, setSelectedMethod] = useState<Method>("crypto");
  const [amount, setAmount] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [requests, setRequests] = useState<BalanceRequest[]>([]);

  useEffect(() => {
    if (!user) return;
    const q = query(
      collection(db, "balanceRequests"),
      where("userId", "==", user.uid)
    );
    const unsub = onSnapshot(q, (snap) => {
      const items = snap.docs.map((d) => ({ id: d.id, ...d.data() } as BalanceRequest));
      items.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
      setRequests(items);
    });
    return () => unsub();
  }, [user]);

  useEffect(() => {
    if (!authLoading && !user) setLocation("/login");
  }, [authLoading, user, setLocation]);

  if (authLoading || !user || !profile) return null;

  const method = METHODS.find((m) => m.id === selectedMethod)!;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(amount);
    if (isNaN(amt) || amt < 1) return;
    setSubmitting(true);
    await addDoc(collection(db, "balanceRequests"), {
      userId: user.uid,
      username: profile.username,
      method: selectedMethod,
      amount: amt,
      status: "pending",
      createdAt: new Date().toISOString(),
    });
    setSubmitting(false);
    setSubmitted(true);
    setAmount("");
    setTimeout(() => setSubmitted(false), 3000);
  };

  const statusColor: Record<string, string> = {
    pending: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20",
    approved: "bg-green-500/10 text-green-400 border-green-500/20",
    rejected: "bg-red-500/10 text-red-400 border-red-500/20",
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="max-w-2xl mx-auto px-4 pt-20 pb-12">
        <div className="mb-8">
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Wallet className="w-6 h-6 text-primary" /> Balance
          </h1>
        </div>

        {/* Current balance */}
        <div className="bg-card border border-border rounded-xl p-6 mb-6 text-center">
          <p className="text-sm text-muted-foreground mb-1">Available Balance</p>
          <p className="text-5xl font-black text-green-400 font-mono" data-testid="text-balance">
            ${profile.balance.toFixed(2)}
          </p>
          <p className="text-xs text-muted-foreground mt-2">USD</p>
        </div>

        {/* Deposit */}
        <div className="bg-card border border-border rounded-xl p-5 mb-6">
          <h2 className="font-semibold mb-4">Deposit Funds</h2>

          {/* Method selector */}
          <div className="grid grid-cols-3 gap-2 mb-5">
            {METHODS.map((m) => {
              const Icon = m.icon;
              return (
                <button
                  key={m.id}
                  onClick={() => setSelectedMethod(m.id)}
                  data-testid={`button-method-${m.id}`}
                  className={`rounded-xl border p-3 text-center transition-all ${
                    selectedMethod === m.id
                      ? "border-primary bg-primary/10 text-primary"
                      : "border-border bg-muted/30 text-muted-foreground hover:border-primary/40"
                  }`}
                >
                  <Icon className="w-5 h-5 mx-auto mb-1" />
                  <p className="text-xs font-medium">{m.label}</p>
                </button>
              );
            })}
          </div>

          {/* Instructions */}
          <div className="bg-muted/50 border border-border/50 rounded-lg p-4 text-sm text-muted-foreground mb-4">
            <p className="font-medium text-foreground mb-1">{method.label}</p>
            <p>{method.instructions}</p>
            <p className="mt-2 text-xs">
              Support: <span className="text-primary font-mono">support@limitedsvault.com</span>
            </p>
          </div>

          {/* Amount form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="amount">Amount (USD)</Label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">$</span>
                <Input
                  id="amount"
                  data-testid="input-amount"
                  type="number"
                  min="1"
                  step="0.01"
                  placeholder="0.00"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="pl-7"
                  required
                />
              </div>
            </div>
            <Button
              type="submit"
              className="w-full glow-primary"
              disabled={submitting || submitted}
              data-testid="button-request-deposit"
            >
              {submitted ? "Request Submitted!" : submitting ? "Submitting..." : "Submit Deposit Request"}
            </Button>
          </form>
        </div>

        {/* History */}
        <div>
          <h2 className="font-semibold mb-3 flex items-center gap-2">
            <Clock className="w-4 h-4 text-primary" /> Deposit History
          </h2>
          {requests.length === 0 ? (
            <p className="text-center text-muted-foreground text-sm py-8">No deposit requests yet.</p>
          ) : (
            <div className="space-y-2">
              {requests.map((r) => (
                <div key={r.id} data-testid={`row-request-${r.id}`} className="bg-card border border-border rounded-lg px-4 py-3 flex items-center gap-3">
                  <div className="flex-1">
                    <p className="font-medium text-sm capitalize">{r.method}</p>
                    <p className="text-xs text-muted-foreground">{new Date(r.createdAt).toLocaleDateString()}</p>
                  </div>
                  <p className="font-bold font-mono">${r.amount.toFixed(2)}</p>
                  <span className={`text-xs px-2 py-0.5 rounded-full border font-medium ${statusColor[r.status] ?? ""}`}>
                    {r.status}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
