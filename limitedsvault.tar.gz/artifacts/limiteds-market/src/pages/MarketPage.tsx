import { useState, useEffect } from "react";
import { Link } from "wouter";
import { collection, query, where, onSnapshot, limit } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useGetMarketStats } from "@workspace/api-client-react";
import { Navbar } from "@/components/Navbar";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { TrendingUp, ShoppingCart, Users, DollarSign, ExternalLink } from "lucide-react";

interface Listing {
  id: string;
  sellerId: string;
  sellerUsername: string;
  assetId: string;
  name: string;
  imageUrl: string;
  rolimonsValue: number;
  listPrice: number;
  status: string;
  createdAt: string;
}

function ListingCard({ listing }: { listing: Listing }) {
  const [imgError, setImgError] = useState(false);
  const fallback = `https://www.roblox.com/asset-thumbnail/image?assetId=${listing.assetId}&width=150&height=150&format=png`;

  return (
    <Link href={`/listing/${listing.id}`}>
      <div
        data-testid={`card-listing-${listing.id}`}
        className="group bg-card border border-border rounded-xl overflow-hidden hover:border-primary/50 hover:shadow-lg transition-all duration-200 cursor-pointer"
      >
        <div className="aspect-square bg-muted relative overflow-hidden">
          <img
            src={imgError ? fallback : (listing.imageUrl || fallback)}
            alt={listing.name}
            onError={() => setImgError(true)}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
          <div className="absolute top-2 right-2">
            <Badge variant="secondary" className="text-xs font-mono">
              #{listing.assetId}
            </Badge>
          </div>
        </div>
        <div className="p-3">
          <p className="font-semibold text-sm truncate mb-1" data-testid={`text-name-${listing.id}`}>{listing.name}</p>
          <p className="text-xs text-muted-foreground mb-2">by {listing.sellerUsername}</p>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-muted-foreground">RAP</p>
              <p className="text-xs font-mono text-muted-foreground">{listing.rolimonsValue.toLocaleString()}</p>
            </div>
            <div className="text-right">
              <p className="text-xs text-muted-foreground">Price</p>
              <p className="text-base font-bold text-primary" data-testid={`text-price-${listing.id}`}>${listing.listPrice.toFixed(2)}</p>
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
}

function StatCard({ icon: Icon, label, value }: { icon: React.ElementType; label: string; value: string }) {
  return (
    <div className="bg-card border border-border rounded-lg p-4 flex items-center gap-3">
      <div className="w-9 h-9 rounded-md bg-primary/10 flex items-center justify-center shrink-0">
        <Icon className="w-4.5 h-4.5 text-primary" />
      </div>
      <div>
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className="font-bold text-sm" data-testid={`stat-${label.replace(/\s/g, "-").toLowerCase()}`}>{value}</p>
      </div>
    </div>
  );
}

export default function MarketPage() {
  const [listings, setListings] = useState<Listing[]>([]);
  const [loadingListings, setLoadingListings] = useState(true);
  const [search, setSearch] = useState("");
  const { data: stats } = useGetMarketStats();

  useEffect(() => {
    const q = query(
      collection(db, "listings"),
      where("status", "==", "active"),
      limit(60)
    );
    const unsub = onSnapshot(q, (snap) => {
      const items = snap.docs.map((d) => ({ id: d.id, ...d.data() } as Listing));
      items.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
      setListings(items);
      setLoadingListings(false);
    });
    return () => unsub();
  }, []);

  const filtered = listings.filter((l) =>
    search === "" || l.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-background">
      <Navbar search={search} onSearch={setSearch} />
      <div className="max-w-7xl mx-auto px-4 pt-20 pb-12">
        {/* Hero */}
        <div className="mb-8">
          <h1 className="text-3xl font-extrabold mb-1">
            Roblox Limiteds Marketplace
          </h1>
          <p className="text-muted-foreground text-sm">
            Buy and sell rare Roblox limited items with trusted escrow trading.
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-8">
          <StatCard icon={ShoppingCart} label="Active Listings" value={String(stats?.totalListings ?? listings.length)} />
          <StatCard icon={TrendingUp} label="Total Trades" value={String(stats?.totalTrades ?? 0)} />
          <StatCard icon={DollarSign} label="Volume" value={`$${(stats?.totalVolume ?? 0).toFixed(0)}`} />
          <StatCard icon={Users} label="Traders" value={String(stats?.totalUsers ?? 0)} />
        </div>

        {/* Listings grid */}
        {loadingListings ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3">
            {Array.from({ length: 12 }).map((_, i) => (
              <div key={i} className="rounded-xl overflow-hidden">
                <Skeleton className="aspect-square w-full" />
                <div className="p-3 space-y-2">
                  <Skeleton className="h-3 w-3/4" />
                  <Skeleton className="h-3 w-1/2" />
                </div>
              </div>
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-24">
            <div className="w-16 h-16 rounded-2xl bg-muted mx-auto flex items-center justify-center mb-4">
              <ShoppingCart className="w-8 h-8 text-muted-foreground" />
            </div>
            <p className="text-lg font-semibold mb-1">No listings found</p>
            <p className="text-muted-foreground text-sm">
              {search ? "Try a different search term." : "Be the first to list a limited!"}
            </p>
            {!search && (
              <Link href="/dashboard">
                <Button className="mt-4 glow-primary">List an Item</Button>
              </Link>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3">
            {filtered.map((listing) => (
              <ListingCard key={listing.id} listing={listing} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
