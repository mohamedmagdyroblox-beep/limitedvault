import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { collection, query, where, onSnapshot } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useAuth } from "@/lib/auth-context";
import { Navbar } from "@/components/Navbar";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { ShoppingBag, ArrowRight } from "lucide-react";

interface Trade {
  id: string;
  listingId: string;
  buyerId: string;
  buyerUsername: string;
  sellerId: string;
  sellerUsername: string;
  itemName: string;
  itemImageUrl: string;
  assetId: string;
  amount: number;
  status: string;
  createdAt: string;
}

const statusColor: Record<string, string> = {
  chatting: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20",
  completed: "bg-green-500/10 text-green-400 border-green-500/20",
  cancelled: "bg-red-500/10 text-red-400 border-red-500/20",
  pending: "bg-blue-500/10 text-blue-400 border-blue-500/20",
};

export default function OrdersPage() {
  const { user, profile, loading: authLoading } = useAuth();
  const [, setLocation] = useLocation();
  const [trades, setTrades] = useState<Trade[]>([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<"buying" | "selling">("buying");

  useEffect(() => {
    if (!user) return;
    const field = tab === "buying" ? "buyerId" : "sellerId";
    const q = query(
      collection(db, "trades"),
      where(field, "==", user.uid)
    );
    setLoading(true);
    const unsub = onSnapshot(q, (snap) => {
      const items = snap.docs.map((d) => ({ id: d.id, ...d.data() } as Trade));
      items.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
      setTrades(items);
      setLoading(false);
    });
    return () => unsub();
  }, [user, tab]);

  useEffect(() => {
    if (!authLoading && !user) setLocation("/login");
  }, [authLoading, user, setLocation]);

  if (authLoading || !user || !profile) return null;

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="max-w-3xl mx-auto px-4 pt-20 pb-12">
        <div className="mb-8">
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <ShoppingBag className="w-6 h-6 text-primary" /> Order History
          </h1>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-6 bg-muted p-1 rounded-lg w-fit">
          {(["buying", "selling"] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              data-testid={`tab-${t}`}
              className={`px-4 py-1.5 rounded-md text-sm font-medium transition-all capitalize ${
                tab === t ? "bg-card text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {t === "buying" ? "As Buyer" : "As Seller"}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3].map((i) => <Skeleton key={i} className="h-20 rounded-xl" />)}
          </div>
        ) : trades.length === 0 ? (
          <div className="text-center py-16 bg-card border border-border rounded-xl">
            <ShoppingBag className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
            <p className="font-semibold">No orders yet</p>
            <p className="text-muted-foreground text-sm mt-1">
              {tab === "buying" ? "Buy a limited from the market to get started." : "List an item to start selling."}
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {trades.map((trade) => (
              <Link key={trade.id} href={`/trade/${trade.id}`}>
                <div
                  data-testid={`row-trade-${trade.id}`}
                  className="bg-card border border-border rounded-xl p-4 flex items-center gap-4 hover:border-primary/40 transition-colors cursor-pointer"
                >
                  <img
                    src={trade.itemImageUrl || `https://www.roblox.com/asset-thumbnail/image?assetId=${trade.assetId}&width=60&height=60&format=png`}
                    alt={trade.itemName}
                    className="w-14 h-14 rounded-lg object-cover bg-muted shrink-0"
                    onError={(e) => { (e.target as HTMLImageElement).src = `https://www.roblox.com/asset-thumbnail/image?assetId=${trade.assetId}&width=60&height=60&format=png`; }}
                  />
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold truncate">{trade.itemName}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {tab === "buying" ? `Seller: ${trade.sellerUsername}` : `Buyer: ${trade.buyerUsername}`}
                    </p>
                    <p className="text-xs text-muted-foreground font-mono mt-0.5">{trade.id.slice(0, 12)}...</p>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="font-bold text-primary">${(trade.amount ?? 0).toFixed(2)}</p>
                    <span className={`text-xs px-2 py-0.5 rounded-full border font-medium mt-1 inline-block ${statusColor[trade.status] ?? ""}`}>
                      {trade.status}
                    </span>
                  </div>
                  <ArrowRight className="w-4 h-4 text-muted-foreground shrink-0" />
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
