import { useState } from "react";
import { Link, useLocation } from "wouter";
import { signOut } from "firebase/auth";
import { auth } from "@/lib/firebase";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ChevronDown, Menu, X, Wallet, LayoutDashboard, LogOut, ShoppingBag, Shield } from "lucide-react";

export function Navbar({ search, onSearch }: { search?: string; onSearch?: (v: string) => void }) {
  const { user, profile } = useAuth();
  const [, setLocation] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleSignOut = async () => {
    await signOut(auth);
    setLocation("/");
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 border-b border-border bg-background/90 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 h-14 flex items-center gap-4">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 shrink-0 mr-2">
          <div className="w-7 h-7 rounded-md bg-primary flex items-center justify-center">
            <span className="text-white font-black text-sm">LV</span>
          </div>
          <span className="font-bold text-base tracking-tight hidden sm:block">LimitedsVault</span>
        </Link>

        {/* Search */}
        {onSearch !== undefined && (
          <div className="flex-1 max-w-sm">
            <input
              data-testid="input-search"
              type="search"
              placeholder="Search limiteds..."
              value={search}
              onChange={(e) => onSearch(e.target.value)}
              className="w-full h-8 px-3 text-sm rounded-md bg-muted border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary"
            />
          </div>
        )}

        <div className="flex-1" />

        {/* Desktop right */}
        <div className="hidden sm:flex items-center gap-2">
          {user && profile ? (
            <>
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-muted text-sm font-mono text-green-400 border border-border">
                <Wallet className="w-3.5 h-3.5" />
                <span data-testid="text-balance">${profile.balance.toFixed(2)}</span>
              </div>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" className="gap-1.5" data-testid="button-user-menu">
                    <span className="max-w-[100px] truncate">{profile.username}</span>
                    <ChevronDown className="w-3.5 h-3.5 opacity-60" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-44">
                  <DropdownMenuItem onClick={() => setLocation("/dashboard")}>
                    <LayoutDashboard className="w-4 h-4 mr-2" /> Dashboard
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLocation("/orders")}>
                    <ShoppingBag className="w-4 h-4 mr-2" /> Orders
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLocation("/balance")}>
                    <Wallet className="w-4 h-4 mr-2" /> Balance
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleSignOut} className="text-destructive">
                    <LogOut className="w-4 h-4 mr-2" /> Sign out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </>
          ) : (
            <>
              <Link href="/login">
                <Button variant="ghost" size="sm" data-testid="button-login">Login</Button>
              </Link>
              <Link href="/signup">
                <Button size="sm" className="glow-primary" data-testid="button-signup">Sign Up</Button>
              </Link>
            </>
          )}
        </div>

        {/* Mobile burger */}
        <button
          className="sm:hidden p-1.5 rounded-md hover:bg-muted"
          onClick={() => setMobileOpen(!mobileOpen)}
          data-testid="button-mobile-menu"
        >
          {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      {/* Mobile dropdown */}
      {mobileOpen && (
        <div className="sm:hidden border-t border-border bg-background px-4 py-3 flex flex-col gap-2">
          {onSearch !== undefined && (
            <input
              type="search"
              placeholder="Search limiteds..."
              value={search}
              onChange={(e) => onSearch?.(e.target.value)}
              className="w-full h-9 px-3 text-sm rounded-md bg-muted border border-border focus:outline-none focus:ring-1 focus:ring-primary"
            />
          )}
          {user && profile ? (
            <>
              <div className="flex items-center gap-2 text-sm text-muted-foreground py-1">
                <Wallet className="w-4 h-4 text-green-400" />
                <span className="font-mono text-green-400">${profile.balance.toFixed(2)}</span>
                <span className="ml-auto text-foreground font-medium">{profile.username}</span>
              </div>
              <Link href="/dashboard" onClick={() => setMobileOpen(false)}>
                <Button variant="ghost" size="sm" className="w-full justify-start gap-2">
                  <LayoutDashboard className="w-4 h-4" /> Dashboard
                </Button>
              </Link>
              <Link href="/orders" onClick={() => setMobileOpen(false)}>
                <Button variant="ghost" size="sm" className="w-full justify-start gap-2">
                  <ShoppingBag className="w-4 h-4" /> Orders
                </Button>
              </Link>
              <Link href="/balance" onClick={() => setMobileOpen(false)}>
                <Button variant="ghost" size="sm" className="w-full justify-start gap-2">
                  <Wallet className="w-4 h-4" /> Balance
                </Button>
              </Link>
              <Button variant="ghost" size="sm" onClick={handleSignOut} className="w-full justify-start gap-2 text-destructive">
                <LogOut className="w-4 h-4" /> Sign out
              </Button>
            </>
          ) : (
            <div className="flex gap-2">
              <Link href="/login" className="flex-1" onClick={() => setMobileOpen(false)}>
                <Button variant="outline" size="sm" className="w-full">Login</Button>
              </Link>
              <Link href="/signup" className="flex-1" onClick={() => setMobileOpen(false)}>
                <Button size="sm" className="w-full">Sign Up</Button>
              </Link>
            </div>
          )}
        </div>
      )}
    </nav>
  );
}
