import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/lib/auth-context";
import NotFound from "@/pages/not-found";
import MarketPage from "@/pages/MarketPage";
import LoginPage from "@/pages/LoginPage";
import SignupPage from "@/pages/SignupPage";
import DashboardPage from "@/pages/DashboardPage";
import VerifyRobloxPage from "@/pages/VerifyRobloxPage";
import ListItemPage from "@/pages/ListItemPage";
import ListingDetailPage from "@/pages/ListingDetailPage";
import TradePage from "@/pages/TradePage";
import BalancePage from "@/pages/BalancePage";
import OrdersPage from "@/pages/OrdersPage";
import AdminPage from "@/pages/AdminPage";

const queryClient = new QueryClient();

function Router() {
  return (
    <Switch>
      <Route path="/" component={MarketPage} />
      <Route path="/login" component={LoginPage} />
      <Route path="/signup" component={SignupPage} />
      <Route path="/dashboard" component={DashboardPage} />
      <Route path="/verify-roblox" component={VerifyRobloxPage} />
      <Route path="/list-item" component={ListItemPage} />
      <Route path="/listing/:id" component={ListingDetailPage} />
      <Route path="/trade/:id" component={TradePage} />
      <Route path="/balance" component={BalancePage} />
      <Route path="/orders" component={OrdersPage} />
      <Route path="/admin" component={AdminPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <Router />
          </WouterRouter>
          <Toaster />
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
