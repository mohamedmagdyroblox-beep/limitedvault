import { Router, type IRouter } from "express";
import {
  GetRobloxVerifyPhraseBody,
  ConfirmRobloxVerificationBody,
  GetRobloxInventoryParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

const VERIFY_WORD_LIST = [
  "sky", "fly", "try", "blue", "red", "run", "sun", "hop", "jet", "zip",
  "glow", "flip", "spin", "dash", "leap", "bolt", "mist", "tide", "wind", "spark",
];

function getRandomWords(n: number): string[] {
  const shuffled = [...VERIFY_WORD_LIST].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, n);
}

async function getRobloxUserByName(username: string): Promise<{ id: string; name: string } | null> {
  try {
    const res = await fetch("https://users.roblox.com/v1/usernames/users", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ usernames: [username], excludeBannedUsers: false }),
    });
    if (!res.ok) return null;
    const data = (await res.json()) as { data: Array<{ id: number; name: string }> };
    if (!data.data || data.data.length === 0) return null;
    const user = data.data[0];
    return { id: String(user.id), name: user.name };
  } catch {
    return null;
  }
}

async function getRobloxUserById(userId: string): Promise<{ id: string; name: string; bio: string } | null> {
  try {
    const res = await fetch(`https://users.roblox.com/v1/users/${userId}`, {
      headers: { "Accept": "application/json" },
    });
    if (!res.ok) return null;
    const data = (await res.json()) as { id: number; name: string; description: string };
    return { id: String(data.id), name: data.name, bio: data.description || "" };
  } catch {
    return null;
  }
}

interface CollectibleItem {
  userAssetId: number;
  serialNumber: number | null;
  assetId: number;
  name: string;
  recentAveragePrice: number;
  originalPrice: number | null;
  assetStock: number | null;
  buildersClubMembershipType: string;
  isOnHold: boolean;
}

async function fetchAllCollectibles(userId: string): Promise<CollectibleItem[]> {
  const all: CollectibleItem[] = [];
  let cursor = "";
  let pages = 0;
  const maxPages = 5; // cap at 500 items

  while (pages < maxPages) {
    const url = `https://inventory.roblox.com/v1/users/${userId}/assets/collectibles?sortOrder=Asc&limit=100${cursor ? `&cursor=${cursor}` : ""}`;
    const res = await fetch(url, {
      headers: { "Accept": "application/json" },
    });

    if (!res.ok) {
      // 403 = inventory is private
      if (res.status === 403) throw new Error("PRIVATE_INVENTORY");
      throw new Error(`Roblox API error: ${res.status}`);
    }

    const data = (await res.json()) as {
      previousPageCursor: string | null;
      nextPageCursor: string | null;
      data: CollectibleItem[];
    };

    all.push(...(data.data || []));
    pages++;

    if (!data.nextPageCursor) break;
    cursor = data.nextPageCursor;
  }

  return all;
}

async function getThumbnailUrls(assetIds: number[]): Promise<Record<number, string>> {
  if (assetIds.length === 0) return {};
  try {
    // Roblox thumbnails API allows up to 100 IDs per request
    const chunks: number[][] = [];
    for (let i = 0; i < assetIds.length; i += 100) {
      chunks.push(assetIds.slice(i, i + 100));
    }

    const urlMap: Record<number, string> = {};
    await Promise.all(
      chunks.map(async (chunk) => {
        const ids = chunk.join(",");
        const res = await fetch(
          `https://thumbnails.roblox.com/v1/assets?assetIds=${ids}&size=150x150&format=Png&isCircular=false`,
          { headers: { "Accept": "application/json" } }
        );
        if (!res.ok) return;
        const data = (await res.json()) as {
          data: Array<{ targetId: number; state: string; imageUrl: string }>;
        };
        for (const item of data.data || []) {
          if (item.state === "Completed" && item.imageUrl) {
            urlMap[item.targetId] = item.imageUrl;
          }
        }
      })
    );
    return urlMap;
  } catch {
    return {};
  }
}

router.post("/roblox/verify/phrase", async (req, res) => {
  const parsed = GetRobloxVerifyPhraseBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request body" });
    return;
  }

  const { robloxUsername } = parsed.data;

  const robloxUser = await getRobloxUserByName(robloxUsername);
  if (!robloxUser) {
    res.status(404).json({ error: "Roblox user not found" });
    return;
  }

  const words = getRandomWords(3);
  const phrase = `limiteds ${words.join(" ")}`;

  res.json({
    phrase,
    robloxUserId: robloxUser.id,
    robloxUsername: robloxUser.name,
  });
});

router.post("/roblox/verify/confirm", async (req, res) => {
  const parsed = ConfirmRobloxVerificationBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request body" });
    return;
  }

  const { robloxUserId, phrase } = parsed.data;

  const robloxUser = await getRobloxUserById(robloxUserId);
  if (!robloxUser) {
    res.status(404).json({ error: "Roblox user not found" });
    return;
  }

  const bio = robloxUser.bio.toLowerCase();
  const phraseNorm = phrase.toLowerCase().trim();
  const verified = bio.includes(phraseNorm);

  if (!verified) {
    res.status(400).json({ error: "Phrase not found in Roblox bio. Make sure you saved your profile." });
    return;
  }

  res.json({
    verified: true,
    robloxUserId: robloxUser.id,
    robloxUsername: robloxUser.name,
  });
});

router.get("/roblox/inventory/:robloxUserId", async (req, res) => {
  const parsed = GetRobloxInventoryParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid params" });
    return;
  }

  const { robloxUserId } = parsed.data;

  try {
    const collectibles = await fetchAllCollectibles(robloxUserId);

    // De-duplicate by assetId (keep highest RAP entry per asset)
    const seen = new Map<number, CollectibleItem>();
    for (const item of collectibles) {
      const existing = seen.get(item.assetId);
      if (!existing || item.recentAveragePrice > existing.recentAveragePrice) {
        seen.set(item.assetId, item);
      }
    }
    const unique = Array.from(seen.values());

    // Fetch thumbnails for all unique asset IDs in parallel
    const assetIds = unique.map((i) => i.assetId);
    const thumbnails = await getThumbnailUrls(assetIds);

    const items = unique
      .map((item) => ({
        assetId: String(item.assetId),
        name: item.name,
        value: item.recentAveragePrice ?? 0,
        rap: item.recentAveragePrice ?? null,
        imageUrl:
          thumbnails[item.assetId] ||
          `https://www.roblox.com/asset-thumbnail/image?assetId=${item.assetId}&width=150&height=150&format=png`,
        quantity: 1,
      }))
      .filter((i) => i.value > 0)
      .sort((a, b) => b.value - a.value);

    // Look up the username
    const userInfo = await getRobloxUserById(robloxUserId);

    res.json({
      robloxUserId,
      robloxUsername: userInfo?.name || "",
      items,
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : "unknown";
    if (msg === "PRIVATE_INVENTORY") {
      res.status(403).json({ error: "This player's inventory is private. Ask them to make it public in Roblox settings." });
    } else {
      res.status(500).json({ error: "Failed to fetch inventory. Please try again." });
    }
  }
});

export default router;
