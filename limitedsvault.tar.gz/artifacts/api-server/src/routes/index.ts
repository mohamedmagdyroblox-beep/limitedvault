import { Router, type IRouter } from "express";
import healthRouter from "./health";
import robloxRouter from "./roblox";
import marketRouter from "./market";

const router: IRouter = Router();

router.use(healthRouter);
router.use(robloxRouter);
router.use(marketRouter);

export default router;
