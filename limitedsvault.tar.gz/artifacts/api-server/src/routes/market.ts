import { Router, type IRouter } from "express";

const router: IRouter = Router();

router.get("/market/stats", async (_req, res) => {
  res.json({
    totalListings: 0,
    totalTrades: 0,
    totalVolume: 0,
    totalUsers: 0,
  });
});

export default router;
