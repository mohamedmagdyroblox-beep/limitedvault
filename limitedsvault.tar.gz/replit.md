# LimitedsVault

A full Roblox Limiteds marketplace similar to Adurite.com — buy, sell, and trade rare Roblox limited items with trusted escrow and live chat.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 8080, path `/api`)
- `pnpm --filter @workspace/limiteds-market run dev` — run the frontend (port 24185, path `/`)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Frontend: React + Vite, wouter routing, Tailwind CSS v4, shadcn/ui
- Auth + DB: Firebase (Auth email/password + Firestore)
- API: Express 5 (api-server), codegen via Orval from OpenAPI spec
- Build: esbuild (CJS bundle for API server)

## Where things live

- `artifacts/limiteds-market/` — React/Vite frontend (all pages)
- `artifacts/api-server/` — Express API server
- `artifacts/api-server/src/routes/roblox.ts` — Roblox verify + inventory routes
- `artifacts/api-server/src/routes/market.ts` — Market stats route
- `lib/api-spec/` — OpenAPI spec (source of truth for API contracts)
- `lib/api-client-react/` — Generated React Query hooks + Zod schemas (from codegen)
- `artifacts/limiteds-market/src/lib/firebase.ts` — Firebase app init
- `artifacts/limiteds-market/src/lib/auth-context.tsx` — AuthProvider + useAuth()

## Firestore Collections

- `users/{uid}` — profile: username, email, balance, verifiedRoblox, robloxUsername, robloxUserId
- `listings/{id}` — sellerId, sellerUsername, assetId, name, imageUrl, rolimonsValue, listPrice, status, createdAt
- `trades/{id}` — buyerId, sellerId, listingId, itemName, amount, status, buyerRobloxUsername
- `chats/{tradeId}/messages/{id}` — live trade chat messages
- `balanceRequests/{id}` — deposit requests: userId, username, method, amount, status

## Architecture decisions

- Firebase Firestore for all data (no PostgreSQL) — avoids needing a managed DB for this project
- Queries avoid composite indexes by sorting client-side (no `where() + orderBy()` on different fields)
- Roblox verification: 4-word phrase injected into Roblox bio, confirmed by API polling bio
- Inventory fetched from Rolimons player API (requires public Roblox inventory + Rolimons profile)
- Balance escrow: Firestore transaction deducts buyer balance and credits seller on "Release Payment"
- Admin panel at `/admin` is client-side password gated (password: egypt123)

## Product

- **Market page** — browse active limited listings with live search and stats
- **Auth** — email/password signup with unique username requirement, no OAuth
- **Roblox verification** — bio-based phrase verification to prove Roblox account ownership
- **List item** — scan Rolimons inventory, select item, set USD price
- **Trade page** — buyer/seller live Firestore chat + escrow payment release
- **Balance** — deposit via crypto/PayPal/CashApp (manual admin approval flow)
- **Orders** — full buy/sell history with trade status
- **Admin panel** — view all trades, users, listings, chat logs, approve/reject deposits

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- Firestore queries: never combine `where(fieldA)` + `orderBy(fieldB)` without a composite index — sort client-side instead
- Rolimons inventory requires the player's inventory to be public AND a Rolimons profile to exist
- Firebase env vars are `VITE_` prefixed so they're available client-side in Vite

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
